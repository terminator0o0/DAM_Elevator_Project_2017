#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "mc9s12c32.h"
#include "mscan.h"


unsigned char CANSendFrame(unsigned long id, unsigned char priority, unsigned char length, unsigned char *txdata);
void CANInit(void);
void delay(int milliseconds);

void CANInit(void)
{
  CANCTL0 = 0x01;
  while(!(CANCTL1&0x21)){};// Loop back mode
  
}
void main()
{
  unsigned char errorflag = NO_ERR;
  unsigned char txbuff[] = "ABCDEFGH";
  
  CANInit();
  
  while(!(CANCTL0&0x10));
  
  CANRFLG = 0xC3;
  CANRIER = 0x01;
  
  EnableInterrupts;
  
  for(;;)
  {
    errorflag = CANSendFrame(ST_ID_100, 0x00, (sizeof(txbuff)-1), txbuff);
    
    delay(20000);
  }
}

unsigned char CANSendFrame(unsigned long id, unsigned char priority, unsigned char length, unsigned char *txdata)
{ 
  unsigned char txbuffer;
  int index=0;
   
  if (!CANTFLG)
  {
    return ERR_BUFFER_FULL;
  }/* Is Transmit Buffer full?? */
    
  
  CANTBSEL = CANTFLG; /* Select lowest empty buffer */
  txbuffer = CANTBSEL; /* Backup selected buffer */
  
  /* Load Id to IDR Register */
  *((unsigned long *) ((unsigned long)(&CANTXIDR0))) = id;
  
  for (index=0; index<length; index++) {
    *(&CANTXDSR0 + index) = txdata[index]; // Load data to Tx buffer
                                            // Data Segment Registers
  }
  
  CANTXDLR = length; // Set Data Length Code 
  CANTXTBPR = priority; // Set Priority 
  CANTFLG = txbuffer; // Start transmission 
  
  while ( (CANTFLG & txbuffer) != txbuffer); // Wait for Transmission completion

}

void delay(int milliseconds)
{
    long pause;
    clock_t now,then;

    pause = milliseconds*(CLOCKS_PER_SEC/1000);
    now = then = clock();
    while( (now-then) < pause )
        now = clock();
}

void interrupt CANRxISR(void)
{
  unsigned char length, index;
  unsigned char rxdata[8];
  
  length = (CANRXDLR&0x0F);
  for (index=0; index<length; index++) 
  {
    rxdata[index] = *(&CANRXDSR0 + index); // Get received data
  }

  CANRFLG = 0x01; // Clear RXF
}